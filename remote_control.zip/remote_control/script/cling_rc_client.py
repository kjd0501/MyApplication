#! /usr/bin/env python

# Author: Abdur Rosyid
# Email: abdoorasheed@gmail.com
# Website: https://abdurrosyid.com

import sys 
import rospy
from std_msgs.msg import Bool,Int32
from remote_control.script import sendCommand
from remote_control.srv import Suction, SuctionRequest, Mode, ModeRequest, Stepper, StepperRequest
 
class cling_rc_client():
    def __init__(self):
        global suction_on_off
        global motion_control
        global stepper_control
        # Name this node, it must be unique
	rospy.init_node('cling_rc_client', anonymous=False)
	
	# Subscribe to /joy and Publish /joy_gripper/state
	rospy.Subscriber("/int_command", int32, self.callback)
	self.suction_on_off = rospy.Publisher('/int_command_suction/state', Int32, queue_size=5)
	self.motion_control = rospy.Publisher('/int_command_mode/state', Int32, queue_size=5)
	self.stepper_control = rospy.Publisher('/int_command_stepper/state', Int32, queue_size=5)

        # wait for this sevice to be running
        rospy.wait_for_service('SuctionOnOFF')
        rospy.wait_for_service('WalkingControl')
        rospy.wait_for_service('StepperControl')
 
        # Create the connection to the service. Remember it's Attach and Stepper services
        suction_on_off = rospy.ServiceProxy('SuctionOnOFF', Suction)
        motion_control = rospy.ServiceProxy('WalkingControl', Mode)
        stepper_control = rospy.ServiceProxy('StepperControl', Stepper)

    def callback(self, int_command):
        global suction_mode
        global suction_result
        global suction_on_off
        global motion_mode
        global motion_result
        global motion_control
        global stepper_mode
        global stepper_result
        global stepper_control

	# Default (no button pressed): all cups on, servo is doing nothing
	# Mode WT1 (button Y pressed) : translational walking move in Direction 1

	# Buttons 
	mode = int32
	mode.data = int_command

        # The initial state is all the cups on (since the cups' solenoids are normally open).
        # Afterwards, if no button is pressed, the default is Cups A,B,C on (Mode 5).
        # When LB and RB are pressed together, all cups are off (Mode 6).

        # The default state of the servo is idle.
        # Servo control is performed by pressing together LB and either A or Y. Otherwise, the servo is idle.

	if mode.data == 1:
	    motion_mode = ModeRequest(1)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for translational walk to Direction 1")
	elif mode.data == 3:
	    motion_mode = ModeRequest(2)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for translational walk to Direction 2")
	elif mode.data == 5:
	    motion_mode = ModeRequest(3)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for translational walk to Direction 3")
	elif mode.data == 7:
	    motion_mode = ModeRequest(4)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for rotational walk 1")
	elif mode.data == 9:
	    motion_mode = ModeRequest(5)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for rotational walk 2")
	elif mode.data == 11:
	    motion_mode = ModeRequest(6)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for rotational walk 3")
	elif mode_manip.data == 1:
	    motion_mode = ModeRequest(7)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving for manipulation")
	elif mode.data == 14:
	    motion_mode = ModeRequest(8)
            motion_result = motion_control(motion_mode)
	    print("Servo is moving to the raised position")
	# elif stepper_mode_1.data == 1 and lb.data == 1:
	#     stepper_mode = StepperRequest(1)
    #         stepper_result = stepper_control(stepper_mode)
	#     print stepper_result
	# elif stepper_mode_2.data == 1 and lb.data == 1:
	#     stepper_mode = StepperRequest(2)
    #         stepper_result = stepper_control(stepper_mode)
	#     print stepper_result
	# elif stepper_mode_1.data == 1 and rb.data == 1:
	#     stepper_mode = StepperRequest(3)
    #         stepper_result = stepper_control(stepper_mode)
	#     print stepper_result
	# elif stepper_mode_2.data == 1 and rb.data == 1:
	#     stepper_mode = StepperRequest(4)
    #         stepper_result = stepper_control(stepper_mode)
	#     print stepper_result
	# elif stepper_mode_1.data == 1:
	#     stepper_mode = StepperRequest(5)
    #         stepper_result = stepper_control(stepper_mode)
	#     print stepper_result
	# elif stepper_mode_2.data == 1:
	#     stepper_mode = StepperRequest(6)
    #         stepper_result = stepper_control(stepper_mode)
	#     print stepper_result
	elif mode.data == 19:
	    suction_mode = SuctionRequest(6) # All cups off
            suction_result = suction_on_off(suction_mode)
	    print suction_result
	elif mode.data == 20:
	    suction_mode = SuctionRequest(5) # Cups A,B,C on; Cup D off
            suction_result = suction_on_off(suction_mode)
	    print suction_result
	    print("Servo and stepper are idle (doing nothing)")
	    
if __name__ == '__main__':
    try:
	cling_rc_client()
	rospy.spin()
    except KeyboardInterrupt:
	print("Shuting down cling_rc_client node")



 

