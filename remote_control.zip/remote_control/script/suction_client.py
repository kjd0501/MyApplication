#! /usr/bin/env python

# Author: Abdur Rosyid
# Email: abdoorasheed@gmail.com
# Website: https://abdurrosyid.com

import sys 
import rospy
from remote_control.srv import Suction, SuctionRequest
 
# init a node as usual
rospy.init_node('SuctionActuationClient')
 
# wait for this sevice to be running
rospy.wait_for_service('SuctionOnOFF')
 
# Create the connection to the service. Remember it's an Attach service
suction_on_off = rospy.ServiceProxy('SuctionOnOFF', Suction)
 
# Create an object of the type AttachRequest. 
resp = SuctionRequest(6)
 
# Now send the request through the connection
result = suction_on_off(resp)

# Done
print result


 

