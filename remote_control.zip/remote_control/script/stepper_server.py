#!/usr/bin/env python

# Author: Abdur Rosyid
# Email: abdoorasheed@gmail.com
# Website: https://abdurrosyid.com

from remote_control.srv import Stepper, StepperResponse
import rospy
import serial
import serial.tools.list_ports

ser = serial.Serial('/dev/ttyACM1', 9600) # both Arduinos for suction and stepper are connected together to the computer

def StepperCallback(req):
    
    if req.mode == 1:
        commandtosend="1"
        stepper_mode = 1
        stepperstatus="Stepper is moving 1 rotation backward"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, stepperstatus)
    elif req.mode == 2:
        commandtosend="2"
        stepper_mode = 2
        stepperstatus="Stepper is moving 1 rotation forward"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, stepperstatus)
    elif req.mode == 3:
        commandtosend="3"
        stepper_mode = 3
        stepperstatus="Stepper is moving (1/10) rotation backward"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, stepperstatus)
    elif req.mode == 4:
        commandtosend="4"
        stepper_mode = 4
        stepperstatus="Stepper is moving (1/10) rotation forward"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, stepperstatus)
    elif req.mode == 5:
        commandtosend="5"
        stepper_mode = 5
        stepperstatus="Stepper is moving (1/20) rotation backward with slower speed"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, stepperstatus)
    elif req.mode == 6:
        commandtosend="6"
        stepper_mode = 6
        stepperstatus="Stepper is moving (1/20) rotation forward with slower speed"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, stepperstatus)
    else:
        stepperstatus="Stepper is idle"
    	print "No command sent to serial port. Status: [%s]"%(stepperstatus)

    return StepperResponse(req.mode)

def stepper_server():
    rospy.init_node('StepperActuationServer')
    s = rospy.Service('StepperControl', Stepper, StepperCallback)
    print "Stepper motor is ready for control"
    rospy.spin()

if __name__ == "__main__":
    stepper_server()
