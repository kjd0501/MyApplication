#! /usr/bin/env python

# Author: Abdur Rosyid
# Email: abdoorasheed@gmail.com
# Website: https://abdurrosyid.com

import sys 
import rospy
from remote_control.srv import Stepper, StepperRequest
 
# init a node as usual
rospy.init_node('StepperActuationClient')
 
# wait for this sevice to be running
rospy.wait_for_service('StepperControl')
 
# Create the connection to the service. Remember it's an Stepper service
stepper_control = rospy.ServiceProxy('StepperControl', Stepper)
 
# Create an object of the type AttachRequest. 
resp = StepperRequest(6)
 
# Now send the request through the connection
result = stepper_control(resp)

# Done
print result


 

