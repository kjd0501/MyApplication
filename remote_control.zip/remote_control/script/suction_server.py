#!/usr/bin/env python

# Author: Abdur Rosyid
# Email: abdoorasheed@gmail.com
# Website: https://abdurrosyid.com

from remote_control.srv import Suction, SuctionResponse
import rospy
import serial
import serial.tools.list_ports

ser = serial.Serial('/dev/ttyACM0', 9600)   

def SuctionCallback(req):
    
    if req.mode == 1:
        commandtosend="1"
        suction_mode = 1
        suctionstatus="Cups A and D on; Other cups off"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, suctionstatus)
    elif req.mode == 2:
        commandtosend="2"
        suction_mode = 2
        suctionstatus="Cups B and D on; Other cups off"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, suctionstatus)
    elif req.mode == 3:
        commandtosend="3"
        suction_mode = 3
        suctionstatus="Cups C and D on; Other cups off"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, suctionstatus)
    elif req.mode == 4:
        commandtosend="4"
        suction_mode = 4
        suctionstatus="Only Cup D on; Other cups off"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, suctionstatus)
    elif req.mode == 5:
        commandtosend="5"
        suction_mode = 5
        suctionstatus="Cups A,B,C on; Cup D off"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, suctionstatus)
    else:
        commandtosend="6"
        suction_mode = 6
        suctionstatus="All cups off"
        ser.write(str(commandtosend))
    	print "Sending command [%s] to serial port. Status: [%s]"%(commandtosend, suctionstatus)

    return SuctionResponse(req.mode)

def suction_server():
    rospy.init_node('SuctionActuationServer')
    s = rospy.Service('SuctionOnOFF', Suction, SuctionCallback)
    print "Cups are ready"
    rospy.spin()

if __name__ == "__main__":
    suction_server()
