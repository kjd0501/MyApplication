import rospy
import bluetooth
from std_msgs.msg import int8

bluetooth_mac = macAddress of robot

def sendCommand(server_sock):
    pub = rospy.Publisher('int_command', int32, queue_size=10)
    rospy.init_node('sendCommand', anonymous=True)
    rate = rospy.Rate(10)

    port = 1
    server_sock.bind(("", port))
    server_sock.listen(1)
    client_sock, address = server_sock.accept()
    print("accepted connection", address)

    while not rospy.is_shutdown():
        data = client_sock.recv(1024)
        print("received [%s]", % data)
        dig = int(data)
        client_sock.close()
        server_sock.close()

        pub.publish(data)


def connect():
    global bluetooth_mac
    global bluetooth_serial_handle

    while (True):
        try:
            bluetooth_serial_handle = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
            bluetooth_serial_handle.connect((bluetooth_mac, 1))
            break;
        except bluetooth.btcommon.BluetoothError as error:
            bluetooth_serial_handle.close()
            rospy.logwarn("Unable to connect, Retrying in 10s...")
            time.sleep(10)
    return bluetooth_serial_handle


if __name__ == '__main__':
    try:
        bluetooth_serial_handle = connect()
        sendCommand(bluetooth_serial_handle)
    except rospy.ROSInterruptException:
        pass


